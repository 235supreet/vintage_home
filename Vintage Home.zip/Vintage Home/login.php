<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: welcome.php");
    exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            // Redirect user to welcome page
                            header("location: welcome.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <style>
            body {
                --color-primary: #00548B;
                --color-primary-dark: rgb(0, 75, 122);
                --color-secondary: #00548B;
                --color-error: #cc3333;
                --color-success: #4bb544;
                --border-radius: 4px;

                margin: 0;
                height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 18px;
                background: url(./background.jpg);
                background-size: cover;
            }

            .container {
                width: 400px;
                max-width: 400px;
                margin: 1rem;
                padding: 2rem;
                box-shadow: 0 0px 40px rgba(0, 0, 0, 0.2);
                border-radius: var(--border-radius);
                background: #ffffff;
            }

            .container,
            .form__input,
            .form__button {
                font: 500 1rem 'Quicksand', sans-serif;
            }

            .form--hidden {
                display: none;
            }

            .form > *:first-child {
                margin-top: 0;
            }

            .form > *:last-child {
                margin-bottom: 0;
            }

            .form__title {
                margin-bottom: 2rem;
                text-align: center;
                color: #00548B;
            }

            .form__message {
                text-align: center;
                margin-bottom: 1rem;
            }

            .form__message--success {
                color: var(--color-success);
            }

            .form__message--error {
                color: var(--color-error);
            }

            .form__input-group {
                margin-bottom: 1rem;
            }

            .form__input {
                display: block;
                width: 100%;
                padding: 0.75rem;
                box-sizing: border-box;
                border-radius: var(--border-radius);
                border: 1px solid #dddddd;
                outline: none;
                background: #fff;
                transition: background 0.2s, border-color 0.2s;
            }

            .form__input:focus {
                border-color: var(--color-primary);
                background: #ffffff;
            }

            .form__input--error {
                color: var(--color-error);
                border-color: var(--color-error);
            }

            .form__input-error-message {
                margin-top: 0.5rem;
                font-size: 0.85rem;
                color: var(--color-error);
            }

            .form__button {
                width: 100%;
                padding: 1rem 2rem;
                font-weight: bold;
                font-size: 1.1rem;
                color: #ffffff;
                border: none;
                border-radius: var(--border-radius);
                outline: none;
                cursor: pointer;
                background: var(--color-primary);
            }

            .form__button:hover {
                background: var(--color-primary-dark);
            }

            .form__button:active {
                transform: scale(0.98);
            }

            .form__text {
                text-align: center;
            }

            .form__link {
                color: var(--color-secondary);
                text-decoration: none;
                cursor: pointer;
            }

            .form__link:hover {
                text-decoration: underline;
            }
            .brand-logo {
                height: 60px;
            }
        </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
         <img src="img/footer-logo.png" align="center">
        <p>Please fill in your credentials to login.</p>

        <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <p>Don't have an account? <a href="register.php">Sign up now</a>.</p>
        </form>
    </div>
</body>
</html>